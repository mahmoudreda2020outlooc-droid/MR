// Heart Animation Logic
function createHeart() {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.innerHTML = '❤️';

    // Random position and size
    heart.style.left = Math.random() * 100 + 'vw';
    heart.style.fontSize = (Math.random() * 20 + 20) + 'px';

    // Random animation duration
    heart.style.animationDuration = (Math.random() * 3 + 2) + 's';

    document.body.appendChild(heart);

    // Remove after animation
    setTimeout(() => {
        heart.remove();
    }, 5000);
}

// Background floating hearts
setInterval(() => {
    if (document.querySelector('.gallery.visible')) {
        createHeart(); // More hearts after button click
    }
}, 300);

// Typing Effect
const messageText = `كل سنة وإنتي حبيبتي\nمش علشان عيد ميلادك وبس\nلكن علشان كل يوم وإنتي فيه جزء من حياتي\n\nوجودك بيفرق وبيطمنّي\nوبيخلّي أي حاجة أبسط وأحلى\n\nبحبك \n  ي احلى ZOZOوكل سنة وأنا مختارك من قلبي ❤️`;

const messageElement = document.getElementById('typing-text');
let charIndex = 0;

// Start typing immediately since script is at end of body
setTimeout(typeWriter, 1000);

function typeWriter() {
    if (charIndex < messageText.length) {
        const char = messageText.charAt(charIndex);

        if (char === '\n') {
            messageElement.innerHTML += '<br>';
        } else if (char !== '\r') {
            // Skip \r, print others
            messageElement.innerHTML += char;
        }

        charIndex++;
        setTimeout(typeWriter, 50);
    }
}


// Button Interaction
const btn = document.getElementById('celebrate-btn');
const gallery = document.getElementById('gallery');
const music = document.getElementById('bg-music');

btn.addEventListener('click', () => {
    // 1. Play Music (Local MP3)
    if (music) {
        music.volume = 0.5;
        music.play().catch(e => console.log("Audio error:", e));
    }

    // 2. Change Button Style to indicate active state
    btn.innerHTML = "Happy Birthday my Love! 🎉";
    btn.style.background = "#fff";
    btn.style.color = "#ff4d6d";

    // 3. Reveal Gallery with animation
    gallery.classList.remove('hidden');
    // Small delay to allow 'display: block' to apply before adding visible class for transition
    setTimeout(() => {
        gallery.classList.add('visible');
    }, 50);

    // 4. Explosion of Hearts
    for (let i = 0; i < 30; i++) {
        setTimeout(createHeart, i * 100);
    }
});
